/**
 * Shared navigation/tab store – re-exports the core store so all modules
 * reference a single, canonical import path instead of the pv-monitoring module.
 *
 * NOTE: The implementation lives in pv-monitoring for historical reasons.
 *       Import from this file in any shared infrastructure code.
 */
export {
  usePVMonitoringStore as useNavigationStore,
  usePVMonitoringStore,
} from '@/modules/pv-monitoring/store/pvMonitoringStore'
