"use client"

import React, { useEffect, useState } from 'react'
import DashboardHeader from './DashboardHeader'
import DashboardSidebar from './DashboardSidebar'
import BreadcrumbNavigation from '@/modules/pv-monitoring/components/BreadcrumbNavigation'
import { formatDateTime } from '@/shared/utils/formatDateTime'
import { useNavigationStore } from '@/shared/store/navigationStore'

export type DashboardLayoutProps = {
  /** Child content rendered inside the main scrollable area. */
  children: React.ReactNode
  /**
   * The sidebar sub-item key that should be highlighted on mount.
   * Matches a value in SIDEBAR_SUB_ITEMS, e.g. "PV", "PCS", "Overview".
   */
  initialActiveTab?: string
  /**
   * When provided, this route is registered in the breadcrumb tab bar on mount.
   */
  visitedRoute?: string
}

/**
 * Canonical reusable dashboard layout.
 *
 * Renders the shared header, collapsible sidebar, breadcrumb tab bar and a
 * flex column that stretches to fill the viewport.  Page-specific content
 * (filters, status tabs, card grids, charts…) is passed as `children`.
 *
 * Usage:
 * ```tsx
 * <DashboardLayout title="PV Monitoring" initialActiveTab="PV" visitedRoute="/pv">
 *   <PVMonitoringContent />
 * </DashboardLayout>
 * ```
 */
export default function DashboardLayout({
  children,
  initialActiveTab = 'PV',
  visitedRoute,
}: DashboardLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState(initialActiveTab)
  const [currentTime, setCurrentTime] = useState(new Date())

  const addVisitedTab = useNavigationStore((s) => s.addVisitedTab)

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    if (visitedRoute) addVisitedTab(visitedRoute)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visitedRoute])

  return (
    <div className="h-screen bg-[#f5f7fa] font-sans text-gray-800 flex flex-col text-[14px] ui-compact">
      <DashboardHeader
        sidebarCollapsed={sidebarCollapsed}
        currentTimeLabel={formatDateTime(currentTime)}
        onToggleSidebar={() => setSidebarCollapsed((s) => !s)}
      />

      <div className="flex flex-1 overflow-hidden">
        <DashboardSidebar
          sidebarCollapsed={sidebarCollapsed}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        <div className="flex-1 min-w-0 overflow-hidden flex flex-col bg-[#f5f7fa]">
          <BreadcrumbNavigation />
          {children}
        </div>
      </div>
    </div>
  )
}
