"use client"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Network, Settings, BarChart2, LayoutGrid, LineChart, JapaneseYen, ChevronDown } from 'lucide-react'
import { useNavigationStore } from '@/shared/store/navigationStore'
import { SIDEBAR_ITEMS, SIDEBAR_SUB_ITEMS, SIDEBAR_ROUTE_MAP } from '@/config/navigation/sidebar'

export type DashboardSidebarProps = {
  sidebarCollapsed: boolean
  activeTab: string
  setActiveTab: (tab: string) => void
}

/**
 * Left navigation sidebar shared across all dashboard pages.
 * Items and routes are driven by config/navigation/sidebar.ts.
 */
export default function DashboardSidebar({
  sidebarCollapsed,
  activeTab,
  setActiveTab,
}: DashboardSidebarProps) {
  const [openMenu, setOpenMenu] = useState<string | null>('Monitoring')
  const router = useRouter()
  const addVisitedTab = useNavigationStore((s) => s.addVisitedTab)

  return (
    <aside
      className={`bg-[#001529] transition-all duration-300 flex flex-col overflow-hidden shrink-0 z-20 self-stretch ${
        sidebarCollapsed ? 'w-11' : 'w-56'
      }`}
    >
      <nav className="flex-1 py-3 overflow-y-auto scrollbar-thin">
        <ul className="space-y-0.5">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon
            return (
              <li key={item.key} className="px-2">
                <div className="flex flex-col">
                  <button
                    onClick={() => {
                      if (item.hasChildren) setOpenMenu((prev) => (prev === item.key ? null : item.key))
                      if (item.key === 'System') setActiveTab('System')
                    }}
                    className={`w-full flex items-center justify-between px-3 rounded-md transition-all duration-200 group ${
                      sidebarCollapsed ? 'justify-center' : ''
                    } ${
                      item.key === activeTab || (item.hasChildren && openMenu === item.key)
                        ? 'text-white'
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                    style={{ height: 44 }}
                  >
                    <div className="flex items-center gap-3">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          item.key === activeTab || (item.hasChildren && openMenu === item.key)
                            ? 'text-[#1890ff]'
                            : 'text-gray-400 group-hover:text-white'
                        }`}
                      />
                      {!sidebarCollapsed && <span className="text-[13px] font-medium">{item.label}</span>}
                    </div>
                    {!sidebarCollapsed && item.hasChildren && (
                      <div className={`transition-transform duration-200 ${openMenu === item.key ? 'rotate-180' : ''}`}>
                        <ChevronDown className="w-3 h-3 opacity-60" />
                      </div>
                    )}
                  </button>

                  {!sidebarCollapsed && item.hasChildren && (
                    <div
                      className={`overflow-hidden transition-all duration-300 ${
                        openMenu === item.key ? 'max-h-[360px] mt-1' : 'max-h-0'
                      }`}
                    >
                      <ul className="space-y-0.5">
                        {SIDEBAR_SUB_ITEMS.map((sub) => (
                          <li key={sub}>
                            <button
                              onClick={() => {
                                setActiveTab(sub)
                                const routePath = SIDEBAR_ROUTE_MAP[sub]
                                if (routePath) {
                                  try {
                                    addVisitedTab(routePath)
                                    router.push(routePath)
                                  } catch {
                                    /* ignore */
                                  }
                                }
                              }}
                              className={`w-full text-left pl-11 pr-3 py-2 text-[12px] rounded-md transition-all duration-200 ${
                                sub === activeTab
                                  ? 'bg-[#1890ff] text-white'
                                  : 'text-gray-400 hover:text-white hover:bg-white/5'
                              }`}
                            >
                              {sub}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </li>
            )
          })}
        </ul>
      </nav>
    </aside>
  )
}
