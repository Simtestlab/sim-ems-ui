export { default } from '@/shared/components/layout/DashboardHeader'
