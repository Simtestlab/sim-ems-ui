export { default } from '@/modules/pv-monitoring/components/BreadcrumbNavigation'
