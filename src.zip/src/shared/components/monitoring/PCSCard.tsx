export { default } from '@/modules/pcs/components/PCSCard'
