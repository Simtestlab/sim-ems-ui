export { default } from '@/shared/components/layout/DashboardSidebar'
