"use client"

import React, { useEffect, useState } from 'react'
import DashboardHeader from '@/shared/components/layout/DashboardHeader'
import DashboardSidebar from '@/shared/components/layout/DashboardSidebar'
import BreadcrumbNavigation from '@/modules/pv-monitoring/components/BreadcrumbNavigation'
import { formatDateTime } from '@/shared/utils/formatDateTime'
import { useNavigationStore } from '@/shared/store/navigationStore'

type Props = {
  children: React.ReactNode
  initialActiveTab?: string
  visitedRoute?: string
}

export default function MonitoringLayout({ children, initialActiveTab = 'PCS', visitedRoute }: Props) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState(initialActiveTab)
  const [currentTime, setCurrentTime] = useState(new Date())

  const addVisitedTab = useNavigationStore((s) => s.addVisitedTab)

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    if (visitedRoute) addVisitedTab(visitedRoute)
  }, [visitedRoute, addVisitedTab])

  return (
    <div className="h-screen bg-[#f5f7fa] font-sans text-gray-800 flex flex-col text-[14px] ui-compact">
      <DashboardHeader
        sidebarCollapsed={sidebarCollapsed}
        currentTimeLabel={formatDateTime(currentTime)}
        onToggleSidebar={() => setSidebarCollapsed((s) => !s)}
      />

      <div className="flex flex-1 overflow-hidden">
        <DashboardSidebar
          sidebarCollapsed={sidebarCollapsed}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        <div className="flex-1 min-w-0 overflow-hidden flex flex-col bg-[#f5f7fa]">
          <BreadcrumbNavigation />
          {children}
        </div>
      </div>
    </div>
  )
}
