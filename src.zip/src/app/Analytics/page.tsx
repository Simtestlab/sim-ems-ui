import AnalyticsPage from "@/modules/Analytics/analyticsPage"

export default AnalyticsPage