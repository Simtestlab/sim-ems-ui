
import SiteMapPage  from "@/modules/Site-Map/sitemapPage"

export default SiteMapPage;

