import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export default async function Home() {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get("access_token")?.value;
  console.log("Access Token:", accessToken);

  if (accessToken) {
    redirect("/dashboard");
  }

  redirect("/login");
}
