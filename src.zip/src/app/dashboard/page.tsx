import OverviewPage from '@/modules/dashboard/pages/OverviewPage'
import MonitoringLayout from '@/shared/components/monitoring/MonitoringLayout'

export default function Page() {
  return (
    <MonitoringLayout initialActiveTab="Overview" visitedRoute="/dashboard">
      <OverviewPage />
    </MonitoringLayout>
  )
}
