import { LivePage } from '@/modules/Live/LivePage';

export default LivePage;
