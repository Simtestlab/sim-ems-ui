import AlertsPage from "@/modules/Alerts/AlertsPage"

export default AlertsPage
