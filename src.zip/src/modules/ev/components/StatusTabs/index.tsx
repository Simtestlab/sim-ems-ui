import SharedMonitoringStatusTabs from '@/shared/components/monitoring/StatusTabs'
import type { MonitoringStatusTabItem } from '@/shared/components/monitoring/StatusTabs'

type EVStatusTabsProps = {
  statusTabs: MonitoringStatusTabItem[]
  selectedStatus: string
  counts: Record<string, number>
  onSelectStatus: (status: string) => void
}

export default function EVStatusTabs({
  statusTabs,
  selectedStatus,
  counts,
  onSelectStatus,
}: EVStatusTabsProps) {
  return (
    <SharedMonitoringStatusTabs
      statusTabs={statusTabs}
      selectedStatus={selectedStatus}
      counts={counts}
      onSelectStatus={onSelectStatus}
    />
  )
}
