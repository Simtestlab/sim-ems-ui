'use client';
import { Navbar } from '../../components/Navbar';

export function LivePage() {
  return (
    <div>
      <div className="w-full">
        <div className="bg-white min-h-[calc(100vh-9.5rem)]">
          <Navbar />
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <p className="text-lg mb-2">Live</p>
              <p className="text-sm">Site-specific widgets and data will appear here</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
