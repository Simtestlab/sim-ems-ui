export function inverterTitleToPV(title: string) {
  return title.replace(/#Inverter$/, '#PV')
}

/**
 * @deprecated Use `formatDateTime` from '@/shared/utils/formatDateTime' instead.
 * Re-exported here for backward compatibility.
 */
export { formatDateTime } from '@/shared/utils/formatDateTime'
