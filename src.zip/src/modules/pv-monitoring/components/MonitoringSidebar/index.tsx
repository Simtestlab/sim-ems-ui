"use client"

/**
 * @deprecated Import from '@/shared/components/layout/DashboardSidebar' directly.
 * This re-export exists for backward compatibility with existing page imports.
 */
export { default } from '@/shared/components/layout/DashboardSidebar'
export type { DashboardSidebarProps } from '@/shared/components/layout/DashboardSidebar'
