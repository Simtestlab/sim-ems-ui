/**
 * @deprecated Import from '@/shared/components/layout/DashboardHeader' directly.
 * This re-export exists for backward compatibility with existing page imports.
 */
export { default } from '@/shared/components/layout/DashboardHeader'
export type { DashboardHeaderProps as MonitoringHeaderProps } from '@/shared/components/layout/DashboardHeader'
