"use client"

import SharedMonitoringFilters from '@/shared/components/monitoring/Filters'

type PCSMonitoringFiltersProps = {
  query: string
  onQueryChange: (value: string) => void
  onSearch: () => void
  onReset: () => void
}

export default function PCSMonitoringFilters({
  query,
  onQueryChange,
  onSearch,
  onReset,
}: PCSMonitoringFiltersProps) {
  return (
    <SharedMonitoringFilters
      query={query}
      onQueryChange={onQueryChange}
      onSearch={onSearch}
      onReset={onReset}
      queryClassName="w-[360px]"
    />
  )
}
