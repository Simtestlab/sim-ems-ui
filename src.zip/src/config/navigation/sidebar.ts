import { Network, Settings, BarChart2, LayoutGrid, LineChart, JapaneseYen } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export type SidebarItem = {
  key: string
  icon: LucideIcon
  label: string
  hasChildren?: boolean
}

/**
 * Top-level sidebar navigation items.
 */
export const SIDEBAR_ITEMS: SidebarItem[] = [
  { key: 'System', icon: Network, label: 'System' },
  { key: 'Settings', icon: Settings, label: 'Settings' },
  { key: 'Monitoring', icon: BarChart2, label: 'Monitoring', hasChildren: true },
  { key: 'Reports', icon: LayoutGrid, label: 'Reports', hasChildren: true },
  { key: 'Economics', icon: LineChart, label: 'Economics', hasChildren: true },
  { key: 'Admin', icon: JapaneseYen, label: 'Admin', hasChildren: true },
]

/**
 * Sub-items shown under collapsible sections.
 */
export const SIDEBAR_SUB_ITEMS: string[] = [
  'Overview',
  'PV',
  'DG',
  'PCS',
  'BMS',
  'FPS',
  'Refrigeration',
  'Meter',
  'EV',
  'Data',
]

/**
 * Mapping from sub-item label → Next.js route path.
 * Only items with a defined route will trigger navigation.
 */
export const SIDEBAR_ROUTE_MAP: Record<string, string> = {
  Overview: '/dashboard',
  PV: '/pv',
  PCS: '/pcs',
  EV: '/ev',
  DG: '/dg',
}
